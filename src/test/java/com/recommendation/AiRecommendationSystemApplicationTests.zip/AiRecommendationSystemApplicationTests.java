package com.recommendation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
 class AiRecommendationSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(AiRecommendationSystemApplication.class, args);
        //test

    }
}